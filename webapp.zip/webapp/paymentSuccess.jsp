<!DOCTYPE html>
<html>
<head>
<title>Payment Successful</title>
<link href="css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">

<h1 style="color:green;">Payment Successful!</h1>
<p>Your order has been placed successfully.</p>

<a href="generateInvoice" class="btn btn-primary mt-3">Download PDF Invoice</a>
<br><br>

<a href="index.jsp" class="btn btn-secondary mt-3">Back to Home</a>

</body>
</html>
