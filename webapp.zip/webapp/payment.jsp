<%@ page import="java.util.*, webmodel.CartItem" %>
<!DOCTYPE html>
<html>
<head>
    <title>Payment</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">

<h2 class="mb-4">Select Payment Method</h2>

<div class="card p-4">

    <h4>Your Total Amount:</h4>

    <%
        List<CartItem> cart = (List<CartItem>) session.getAttribute("CART");
        double total = 0;

        if (cart != null) {
            for (CartItem item : cart) {
                total += item.getTotal();
            }
        }
    %>

    <h3 style="color:green;">INR <%= total %></h3>

    <hr>

    <form action="paymentSuccess.jsp" method="post">

        <label><input type="radio" name="payment" value="upi" required> UPI Payment</label><br>
        <label><input type="radio" name="payment" value="card"> Credit / Debit Card</label><br>
        <label><input type="radio" name="payment" value="cod"> Cash On Delivery</label>

        <br><br>

        <button class="btn btn-success btn-lg btn-block">Proceed to Pay</button>

    </form>

</div>

</body>
</html>
