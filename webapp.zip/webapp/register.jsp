<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    String msg = (String) request.getAttribute("message");
    String err = (String) request.getAttribute("error");
%>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Register • Shop</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/auth.css" />
</head>
<body class="auth-body">

  <div class="auth-page">
    <div class="auth-card" role="group" aria-label="Register card">

      <div class="auth-side auth-side--brand">
        <div class="brand-mark">
          <div class="brand-badge">SHOP</div>
          <div class="brand-title">Create account</div>
          <div class="brand-sub">Save details for faster checkout and exclusive deals.</div>
        </div>
        <div class="brand-mini">
          <div class="mini-pill">One-click checkout</div>
          <div class="mini-pill">Order history</div>
          <div class="mini-pill">Profile & address</div>
        </div>
      </div>

      <div class="auth-side auth-side--form">
        <div class="form-head">
          <h1 class="h1">Register</h1>
          <p class="muted">Fill the form—your account is ready in a few seconds.</p>
        </div>

        <% if (err != null && !err.isBlank()) { %>
          <div class="alert alert--error"><%= err %></div>
        <% } %>
        <% if (msg != null && !msg.isBlank()) { %>
          <div class="alert alert--success"><%= msg %></div>
        <% } %>

        <form class="auth-form" method="post" action="${pageContext.request.contextPath}/register" autocomplete="on" novalidate>
          <label class="field">
            <span class="label">Full Name</span>
            <input class="input" type="text" name="fullName" required placeholder="e.g. Trush Prajapati"/>
          </label>

          <label class="field">
            <span class="label">Username</span>
            <input class="input" type="text" name="username" required minlength="3" placeholder="e.g. trushp"/>
          </label>

          <label class="field">
            <span class="label">Email</span>
            <input class="input" type="email" name="email" required placeholder="name@mail.com"/>
          </label>

          <label class="field">
            <span class="label">Mobile Number (India)</span>
            <input class="input" type="tel" name="mobile" required pattern="^[6-9]\\d{9}$" placeholder="9xxxxxxxxx"/>
          </label>

          <label class="field">
            <span class="label">Password</span>
            <div class="password-wrap">
              <input class="input" id="regPass" type="password" name="password" required minlength="6" placeholder="At least 6 characters"/>
              <button class="icon-btn" type="button" onclick="togglePass('regPass')" aria-label="Toggle password">👁</button>
            </div>
          </label>

          <label class="field">
            <span class="label">Confirm Password</span>
            <div class="password-wrap">
              <input class="input" id="regPass2" type="password" name="confirmPassword" required minlength="6" placeholder="Re-type password"/>
              <button class="icon-btn" type="button" onclick="togglePass('regPass2')" aria-label="Toggle password">👁</button>
            </div>
          </label>

          <button class="btn btn--primary" type="submit">Create account</button>
        </form>

        <div class="footer">
          <span class="muted">Already have an account?</span>
          <a class="link" href="${pageContext.request.contextPath}/login.jsp">Login</a>
        </div>
      </div>

      <div class="auth-ambient" aria-hidden="true"></div>
    </div>
  </div>

  <script>
    function togglePass(id) {
      const el = document.getElementById(id);
      el.type = (el.type === "password") ? "text" : "password";
    }
  </script>
</body>
</html>
