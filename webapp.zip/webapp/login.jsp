<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    String msg = (String) request.getAttribute("message");
    String err = (String) request.getAttribute("error");
%>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login • Shop</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/auth.css" />
</head>
<body class="auth-body">

  <div class="auth-page">
    <div class="auth-card" role="group" aria-label="Login card">

      <div class="auth-side auth-side--brand">
        <div class="brand-mark">
          <div class="brand-badge">SHOP</div>
          <div class="brand-title">Welcome back</div>
          <div class="brand-sub">Sign in to continue your checkout & orders.</div>
        </div>
        <div class="brand-mini">
          <div class="mini-pill">Fast checkout</div>
          <div class="mini-pill">Secure sessions</div>
          <div class="mini-pill">Order tracking</div>
        </div>
      </div>

      <div class="auth-side auth-side--form">
        <div class="form-head">
          <h1 class="h1">Login</h1>
          <p class="muted">Use your credentials to access your account.</p>
        </div>

        <% if (err != null && !err.isBlank()) { %>
          <div class="alert alert--error"><%= err %></div>
        <% } %>
        <% if (msg != null && !msg.isBlank()) { %>
          <div class="alert alert--success"><%= msg %></div>
        <% } %>

        <form class="auth-form" method="post" action="${pageContext.request.contextPath}/login" autocomplete="on" novalidate>
          <label class="field">
            <span class="label">Email or Username</span>
            <input class="input" type="text" name="loginId" required placeholder="e.g. alex or alex@mail.com" />
          </label>

          <label class="field">
            <span class="label">Password</span>
            <div class="password-wrap">
              <input class="input" id="loginPass" type="password" name="password" required placeholder="••••••••" />
              <button class="icon-btn" type="button" onclick="togglePass('loginPass')" aria-label="Toggle password">
                👁
              </button>
            </div>
          </label>

          <div class="row">
            <label class="remember">
              <input type="checkbox" name="remember" value="true" />
              <span>Remember me</span>
            </label>
            <a class="link" href="${pageContext.request.contextPath}/forgot.jsp">Forgot password?</a>
          </div>

          <button class="btn btn--primary" type="submit">Sign in</button>
        </form>

        <div class="footer">
          <span class="muted">New here?</span>
          <a class="link" href="${pageContext.request.contextPath}/register.jsp">Create an account</a>
        </div>
      </div>

      <div class="auth-ambient" aria-hidden="true"></div>
    </div>
  </div>

  <script>
    function togglePass(id) {
      const el = document.getElementById(id);
      el.type = (el.type === "password") ? "text" : "password";
    }
  </script>
</body>
</html>
