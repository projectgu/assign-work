package Dao;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import webmodel.CartItem;
import webmodel.Product;

public class CartDAO {

    @SuppressWarnings("unchecked")
    public static List<CartItem> getCart(HttpSession session) {
        List<CartItem> cart = (List<CartItem>) session.getAttribute("CART");
        if (cart == null) {
            cart = new ArrayList<>();
            session.setAttribute("CART", cart);
        }
        return cart;
    }

    public static void addToCart(HttpSession session, Product p) {
        List<CartItem> cart = getCart(session);

        for (CartItem item : cart) {
            if (item.getProduct().getId() == p.getId()) {
                item.setQty(item.getQty() + 1);
                return;
            }
        }

        cart.add(new CartItem(p, 1));
    }
}
