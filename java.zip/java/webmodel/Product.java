package webmodel;

public class Product {
    private int id;
    private String name;
    private double price;
    private String image;

    public Product() {} 

    public Product(int id, String name, double price, String image) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.image = image;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public String getImage() { return image; }
}
