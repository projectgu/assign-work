package servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import Dao.UserDAO;
import webmodel.User;

import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String loginId = request.getParameter("loginId");  // username or email
        String password = request.getParameter("password");

        UserDAO dao = new UserDAO();
        User user = dao.login(loginId, password);

        if (user != null) {
            // --------- LOGIN SUCCESS ----------
            HttpSession session = request.getSession();
            session.setAttribute("user", user);

            // Redirect to dashboard or home page
            response.sendRedirect("index.jsp");

        } else {
            // --------- LOGIN FAILED ----------
            request.setAttribute("error", "Invalid Username/Email or Password!");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
