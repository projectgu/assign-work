package servlet;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import webmodel.CartItem;

// iText 7 imports
import com.itextpdf.kernel.pdf.*;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.*;
import com.itextpdf.layout.property.UnitValue;
import com.itextpdf.layout.property.TextAlignment;

@WebServlet("/generateInvoice")
public class InvoiceServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<CartItem> cart = (List<CartItem>) request.getSession().getAttribute("CART");

        if (cart == null || cart.isEmpty()) {
            response.sendRedirect("index.jsp");
            return;
        }

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=Invoice.pdf");

        PdfWriter writer = new PdfWriter(response.getOutputStream());
        PdfDocument pdfDoc = new PdfDocument(writer);
        Document document = new Document(pdfDoc);

        // TITLE
        Paragraph title = new Paragraph("INVOICE")
                .setFontSize(22)
                .setBold()
                .setTextAlignment(TextAlignment.CENTER);

        document.add(title);
        document.add(new Paragraph("\n"));

        // DATE + ORDER ID
        document.add(new Paragraph("Date: " + LocalDate.now()));
        document.add(new Paragraph("Order ID: INV-" + System.currentTimeMillis()));
        document.add(new Paragraph("\n"));

        // TABLE
        Table table = new Table(UnitValue.createPercentArray(new float[] {4, 1, 2, 2}))
                .useAllAvailableWidth();

        table.addHeaderCell("Product");
        table.addHeaderCell("Qty");
        table.addHeaderCell("Price");
        table.addHeaderCell("Total");

        double subtotal = 0;

        for (CartItem item : cart) {
            table.addCell(item.getProduct().getName());
            table.addCell(String.valueOf(item.getQty()));
            table.addCell("₹" + item.getProduct().getPrice());
            table.addCell("₹" + item.getTotal());

            subtotal += item.getTotal();
        }

        document.add(table);

        document.add(new Paragraph("\nSubtotal: ₹" + subtotal));
        document.add(new Paragraph("Grand Total: ₹" + subtotal).setBold());

        document.close();

        // OPTIONAL: clear cart
        request.getSession().removeAttribute("CART");
    }
}
