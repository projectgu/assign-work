package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import webmodel.CartItem;

@WebServlet("/updateQty")
public class UpdateQuantityServlet extends HttpServlet {

    @SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        String action = request.getParameter("action");

        HttpSession session = request.getSession();
        List<CartItem> cart = (List<CartItem>) session.getAttribute("CART");

        if (cart != null) {
            for (CartItem item : cart) {
                if (item.getProduct().getId() == id) {
                    if ("inc".equals(action)) {
                        item.setQty(item.getQty() + 1);
                    } else if ("dec".equals(action) && item.getQty() > 1) {
                        item.setQty(item.getQty() - 1);
                    }
                    break;
                }
            }
        }

        response.sendRedirect("cart.jsp");
    }
}
