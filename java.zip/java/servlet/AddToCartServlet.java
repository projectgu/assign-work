package servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import Dao.CartDAO;
import webmodel.CartItem;
import webmodel.Product;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/addToCart")
public class AddToCartServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        double price = Double.parseDouble(request.getParameter("price"));
        String image = request.getParameter("image");

        HttpSession session = request.getSession();

        @SuppressWarnings("unchecked")
		List<CartItem> cart = (List<CartItem>) session.getAttribute("CART");
        if (cart == null) {
            cart = new ArrayList<>();
        }

        boolean found = false;
        for (CartItem item : cart) {
            if (item.getProduct().getId() == id) {
                item.setQty(item.getQty() + 1);
                found = true;
                break;
            }
        }

        if (!found) {
            Product p = new Product(id, name, price, image);
            cart.add(new CartItem(p, 1));
        }

        session.setAttribute("CART", cart);
        response.sendRedirect("cart.jsp");
    }
}
