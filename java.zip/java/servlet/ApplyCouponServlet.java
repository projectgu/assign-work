package servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/applyCoupon")
public class ApplyCouponServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String code = request.getParameter("coupon");
        HttpSession session = request.getSession();

        double discount = 0;

        if (code != null) {
            code = code.trim().toUpperCase();

            switch (code) {
                case "SAVE10":
                    discount = 10;  // flat ₹10 off
                    break;

                case "SAVE50":
                    discount = 50;  // flat ₹50 off
                    break;

                case "OFF10":
                    discount = -1;  // 10% discount
                    break;

                default:
                    session.setAttribute("COUPON_ERROR", "Invalid coupon code");
            }
        }

        session.setAttribute("COUPON", code);
        session.setAttribute("DISCOUNT", discount);

        response.sendRedirect("cart.jsp");
    }
}
